# 🏡 Devanjali Homestay — Website

A complete, professional booking website for **Devanjali Homestay**, Haridwar — with user accounts,
live room availability by calendar dates, secure online payments, and an AI concierge chatbot.

Built with **Node.js + Express + SQLite** on the backend and plain **HTML/CSS/JavaScript** on the
frontend (no build step required).

---

## ✨ Features

- **9 rooms** pre-loaded: 7 Deluxe AC Rooms (₹1,800/night) + 2 Comfort Non-AC Rooms (₹1,100/night)
- **User accounts** — signup/login with hashed passwords (bcrypt) and JWT sessions
- **Live availability calendar** — pick check-in/check-out dates (Flatpickr), see only rooms that
  are actually free for those dates
- **Booking + secure payments** — Razorpay checkout integration (India's most common gateway,
  supports UPI, cards, netbanking, wallets)
- **"My Bookings" dashboard** — view, track, and cancel bookings
- **AI chatbot** — floating concierge widget on every page. Uses the Claude API for natural
  conversation if you add an API key, and automatically falls back to a smart FAQ-matching bot
  if you don't — so it works out of the box either way
- **Photo & video gallery** — real property photos and video walkthroughs
- **Location & contact page** — embedded Google Map + WhatsApp quick-contact
- Fully responsive, mobile-friendly design

---

## 🚀 Quick start

```bash
# 1. Install dependencies
npm install

# 2. Copy the environment template and fill in your keys
cp .env.example .env

# 3. Seed the database with the 9 rooms (runs automatically on first start too)
npm run seed

# 4. Start the server
npm start
```

Then open **http://localhost:3000** in your browser. That's it — signup, browse rooms, and book
a room. Without any payment keys configured, the payment step runs in **demo mode** (see below)
so you can test the entire flow end-to-end immediately.

For development with auto-restart on file changes:
```bash
npm run dev
```

---

## 🔑 Setting up real payments (Razorpay)

1. Create a free account at **[dashboard.razorpay.com](https://dashboard.razorpay.com/)**
2. Go to **Settings → API Keys** and generate a **Test** key pair first
3. Copy the `Key Id` and `Key Secret` into your `.env` file:
   ```
   RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
   RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxx
   ```
4. Restart the server. Bookings will now open a real Razorpay checkout popup (UPI/card/netbanking).
5. When you're ready to accept real money, switch to your **Live** keys from the same dashboard page.

> Until you add real keys, the site runs in **demo mode**: the booking flow works completely
> (order creation → checkout → confirmation) but no real transaction happens — this is exactly
> so you (or anyone testing the site) can see the whole experience without needing a merchant
> account first.

---

## 🤖 Setting up the AI chatbot (optional but recommended)

The chatbot works immediately with **zero configuration** using a built-in FAQ-matching engine
that knows all the homestay's real details (prices, address, amenities, etc).

To make it a fully conversational AI instead:

1. Get an API key from **[console.anthropic.com](https://console.anthropic.com/)**
2. Add it to `.env`:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxx
   ```
3. Restart the server — the chatbot (`routes/chat.js`) will automatically start using Claude for
   natural, contextual replies, still grounded in the homestay's real facts (see the
   `HOMESTAY_CONTEXT` prompt inside that file — edit it any time to update what the bot knows).

If the API key is missing or a request fails for any reason, it automatically and silently falls
back to the FAQ bot — the chat widget never breaks.

---

## 📁 Project structure

```
devanjali-homestay/
├── server.js                 # Express app entry point
├── package.json
├── .env.example               # Copy to .env and fill in your keys
├── db/
│   ├── database.js            # SQLite schema (users, rooms, bookings, chat_logs)
│   ├── seed.js                 # Seeds the 9 rooms on first run
│   └── devanjali.db            # Created automatically (SQLite file)
├── middleware/
│   └── auth.js                 # JWT auth middleware
├── routes/
│   ├── auth.js                  # signup / login / me
│   ├── rooms.js                  # list rooms / check availability
│   ├── bookings.js                # create / list / cancel bookings
│   ├── payment.js                  # Razorpay order + verification
│   └── chat.js                      # AI chatbot endpoint
└── public/                     # Frontend (static, no build step)
    ├── index.html               # Homepage
    ├── rooms.html                # Room listing + availability search
    ├── booking.html                # Guest details + payment
    ├── login.html / signup.html     # Auth pages
    ├── dashboard.html                # "My Bookings"
    ├── gallery.html                   # Photo/video gallery
    ├── contact.html                    # Location, map, contact form
    ├── partials/header.html, footer.html
    ├── css/style.css
    ├── js/api.js, components.js, chatbot.js
    └── assets/images/*, assets/videos/*   # Real property photos & videos
```

---

## 🛠️ Customizing

- **Room details / prices**: edit `db/seed.js`, then delete `db/devanjali.db` and restart to reseed
  (⚠️ this wipes existing bookings — for a live site, write a small migration script instead)
- **Chatbot knowledge**: edit `HOMESTAY_CONTEXT` in `routes/chat.js`, and the FAQ rules in the same file
- **Colors/fonts/design**: all in `public/css/style.css` — the palette is defined as CSS variables
  at the top of the file
- **Photos/videos**: add files to `public/assets/images/` or `public/assets/videos/` and reference
  them from the HTML pages or room records

---

## 🌐 Deploying

This is a standard Node.js app and can be deployed to any Node host: Render, Railway, DigitalOcean
App Platform, a VPS with PM2 + Nginx, etc.

1. Set your real environment variables (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `JWT_SECRET`,
   `ANTHROPIC_API_KEY`) in your hosting provider's dashboard — never commit `.env` to git
2. Make sure the `db/` folder is on **persistent storage** (SQLite writes to a file) — most
   platforms support a persistent disk/volume; alternatively swap `better-sqlite3` for a hosted
   Postgres database if your platform only offers ephemeral storage
3. Point your domain at the app and you're live

---

## 📞 Homestay details reflected on the site

- **Address**: Plot no. 1, Khasra no. 245, Alaknanda Gate, near Patanjali Yogpeeth Phase-2, near
  Crystal World, Roorkee Road, NH-58, Santarshah, Badheri Rajputan, Haridwar, Uttarakhand 249402
- **Phone**: +91 95688 31926
- **Rooms**: 7 AC (₹1,800/night) + 2 Non-AC (₹1,100/night) = 9 total

---

Built with ❤️ for Devanjali Homestay.