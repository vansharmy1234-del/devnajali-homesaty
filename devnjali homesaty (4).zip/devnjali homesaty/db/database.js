const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'devanjali.db'));
db.pragma('journal_mode = WAL');

// ---------- SCHEMA ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_number TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,              -- 'AC' or 'Non-AC'
  price_per_night INTEGER NOT NULL,
  max_guests INTEGER DEFAULT 3,
  bed_type TEXT DEFAULT 'King Size Bed',
  description TEXT,
  amenities TEXT,                  -- JSON string array
  image TEXT,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_ref TEXT UNIQUE NOT NULL,
  user_id INTEGER NOT NULL,
  room_id INTEGER NOT NULL,
  check_in TEXT NOT NULL,          -- YYYY-MM-DD
  check_out TEXT NOT NULL,         -- YYYY-MM-DD
  nights INTEGER NOT NULL,
  guests INTEGER DEFAULT 1,
  total_amount INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',   -- pending, confirmed, cancelled
  payment_status TEXT DEFAULT 'unpaid', -- unpaid, paid, refunded
  razorpay_order_id TEXT,
  razorpay_payment_id TEXT,
  guest_name TEXT,
  guest_phone TEXT,
  guest_email TEXT,
  special_request TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);

CREATE TABLE IF NOT EXISTS chat_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  message TEXT,
  reply TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
`);

module.exports = db;