const db = require('./database');

const acAmenities = JSON.stringify([
  'Split Air Conditioner', 'Free High-Speed Wi-Fi', 'King Size Bed',
  'Attached Western Bathroom', 'Hot Water Geyser', 'Work Desk & Chair',
  'LED TV', 'Complimentary Toiletries', 'Daily Housekeeping', 'Wide Windows with Sunlight'
]);

const nonAcAmenities = JSON.stringify([
  'Ceiling Fan', 'Free High-Speed Wi-Fi', 'King Size Bed',
  'Attached Western Bathroom', 'Hot Water Geyser', 'Work Desk & Chair',
  'LED TV', 'Complimentary Toiletries', 'Daily Housekeeping'
]);

const images = [
  'room-bed-1.jpg', 'room-corridor.jpg', 'room-dresser.jpg',
  'room-bathroom-1.jpg', 'room-bathroom-corridor.jpg', 'lobby-1.jpg', 'lobby-2.jpg'
];

const rooms = [];

// 7 AC Rooms
for (let i = 1; i <= 7; i++) {
  rooms.push({
    room_number: `AC-10${i}`,
    name: `Deluxe AC Room ${i}`,
    type: 'AC',
    price_per_night: 1800,
    max_guests: 3,
    bed_type: 'King Size Bed',
    description: 'A spacious, sunlit deluxe room with a plush king-size bed, dedicated work desk, and a fully tiled attached bathroom with hot water. Cooled by a premium split AC — ideal for families, couples, and business travellers alike.',
    amenities: acAmenities,
    image: images[i % images.length]
  });
}

// 2 Non-AC Rooms
for (let i = 1; i <= 2; i++) {
  rooms.push({
    room_number: `NAC-20${i}`,
    name: `Comfort Non-AC Room ${i}`,
    type: 'Non-AC',
    price_per_night: 1100,
    max_guests: 2,
    bed_type: 'King Size Bed',
    description: 'A cosy, budget-friendly room with all essential comforts — a comfortable king-size bed, ceiling fan, attached western bathroom with geyser, and free Wi-Fi. Great value for solo travellers and short stays.',
    amenities: nonAcAmenities,
    image: images[(i + 5) % images.length]
  });
}

const insert = db.prepare(`
  INSERT INTO rooms (room_number, name, type, price_per_night, max_guests, bed_type, description, amenities, image)
  VALUES (@room_number, @name, @type, @price_per_night, @max_guests, @bed_type, @description, @amenities, @image)
`);

const existing = db.prepare('SELECT COUNT(*) as c FROM rooms').get();
if (existing.c === 0) {
  const insertMany = db.transaction((rms) => {
    for (const r of rms) insert.run(r);
  });
  insertMany(rooms);
  console.log(`✅ Seeded ${rooms.length} rooms (7 AC @ ₹1800/night, 2 Non-AC @ ₹1100/night)`);
} else {
  console.log(`ℹ️  Rooms table already has ${existing.c} rooms. Skipping seed. (Delete db/devanjali.db to reseed)`);
}