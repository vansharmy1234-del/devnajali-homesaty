const express = require('express');
const router = express.Router();
const db = require('../db/database');

// Turn the DB's raw amenities JSON string into a real array before sending it out
function formatRoom(room) {
  return {
    ...room,
    amenities: room.amenities ? JSON.parse(room.amenities) : []
  };
}

// GET /api/rooms  -> all active rooms
router.get('/', (req, res) => {
  try {
    const rooms = db.prepare('SELECT * FROM rooms WHERE active = 1 ORDER BY type, room_number').all();
    res.json({ rooms: rooms.map(formatRoom) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load rooms.' });
  }
});

// GET /api/rooms/availability/search?check_in=YYYY-MM-DD&check_out=YYYY-MM-DD
// IMPORTANT: this specific route must be declared BEFORE '/:id',
// otherwise Express will treat "availability" as a room id.
router.get('/availability/search', (req, res) => {
  const { check_in, check_out } = req.query;

  if (!check_in || !check_out) {
    return res.status(400).json({ error: 'check_in and check_out are required.' });
  }

  try {
    const rooms = db.prepare('SELECT * FROM rooms WHERE active = 1 ORDER BY type, room_number').all();

    // A room is unavailable if it has a non-cancelled booking whose dates overlap the requested range
    const overlapStmt = db.prepare(`
      SELECT COUNT(*) AS c FROM bookings
      WHERE room_id = ?
        AND status != 'cancelled'
        AND check_in < ?
        AND check_out > ?
    `);

    const withAvailability = rooms.map((room) => {
      const { c } = overlapStmt.get(room.id, check_out, check_in);
      return { ...formatRoom(room), available: c === 0 };
    });

    res.json({ rooms: withAvailability });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not check availability.' });
  }
});

// GET /api/rooms/:id -> single room
router.get('/:id', (req, res) => {
  try {
    const room = db.prepare('SELECT * FROM rooms WHERE id = ? AND active = 1').get(req.params.id);
    if (!room) return res.status(404).json({ error: 'Room not found.' });
    res.json({ room: formatRoom(room) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load room.' });
  }
});

module.exports = router;