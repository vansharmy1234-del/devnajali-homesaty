const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

function makeBookingRef() {
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `DJ-${Date.now().toString().slice(-6)}${rand}`;
}

function nightsBetween(checkIn, checkOut) {
  const a = new Date(checkIn);
  const b = new Date(checkOut);
  return Math.round((b - a) / (1000 * 60 * 60 * 24));
}

// POST /api/bookings  -> create a pending booking
router.post('/', requireAuth, (req, res) => {
  const { room_id, check_in, check_out, guests, guest_name, guest_phone, guest_email, special_request } = req.body;

  if (!room_id || !check_in || !check_out || !guest_name || !guest_phone || !guest_email) {
    return res.status(400).json({ error: 'Please fill in all required booking details.' });
  }

  const nights = nightsBetween(check_in, check_out);
  if (nights <= 0) {
    return res.status(400).json({ error: 'Check-out date must be after check-in date.' });
  }

  try {
    const room = db.prepare('SELECT * FROM rooms WHERE id = ? AND active = 1').get(room_id);
    if (!room) return res.status(404).json({ error: 'Room not found.' });

    const overlap = db.prepare(`
      SELECT COUNT(*) AS c FROM bookings
      WHERE room_id = ? AND status != 'cancelled' AND check_in < ? AND check_out > ?
    `).get(room_id, check_out, check_in);
    if (overlap.c > 0) {
      return res.status(409).json({ error: 'This room is no longer available for the selected dates.' });
    }

    const total_amount = nights * room.price_per_night;
    const booking_ref = makeBookingRef();

    const insert = db.prepare(`
      INSERT INTO bookings
        (booking_ref, user_id, room_id, check_in, check_out, nights, guests, total_amount,
         guest_name, guest_phone, guest_email, special_request)
      VALUES (@booking_ref, @user_id, @room_id, @check_in, @check_out, @nights, @guests, @total_amount,
              @guest_name, @guest_phone, @guest_email, @special_request)
    `);
    const info = insert.run({
      booking_ref, user_id: req.user.id, room_id, check_in, check_out, nights,
      guests: guests || 1, total_amount, guest_name, guest_phone, guest_email,
      special_request: special_request || null
    });

    const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json({ booking });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create booking. Please try again.' });
  }
});

// GET /api/bookings/my  -> logged-in user's bookings, newest first
router.get('/my', requireAuth, (req, res) => {
  try {
    const bookings = db.prepare(`
      SELECT b.*, r.name AS room_name, r.image AS room_image, r.room_number
      FROM bookings b
      JOIN rooms r ON r.id = b.room_id
      WHERE b.user_id = ?
      ORDER BY b.created_at DESC
    `).all(req.user.id);

    res.json({ bookings });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load your bookings.' });
  }
});

// POST /api/bookings/:id/cancel
router.post('/:id/cancel', requireAuth, (req, res) => {
  try {
    const booking = db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found.' });

    db.prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?").run(booking.id);
    res.json({ message: 'Booking cancelled.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not cancel booking.' });
  }
});

module.exports = router;