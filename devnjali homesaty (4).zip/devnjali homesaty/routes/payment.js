const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const hasRazorpayKeys = !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  && !process.env.RAZORPAY_KEY_ID.includes('xxxx'));

let razorpay = null;
if (hasRazorpayKeys) {
  const Razorpay = require('razorpay');
  razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
  });
}

// POST /api/payment/create-order
router.post('/create-order', requireAuth, async (req, res) => {
  const { booking_id } = req.body;

  try {
    const booking = db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?').get(booking_id, req.user.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found.' });

    const amountPaise = booking.total_amount * 100;

    // No live Razorpay keys configured -> run in demo mode so the flow can still be tested end to end
    if (!razorpay) {
      return res.json({
        demo_mode: true,
        key_id: 'demo',
        order: { id: 'demo_order_' + booking.id, amount: amountPaise, currency: 'INR' }
      });
    }

    const order = await razorpay.orders.create({
      amount: amountPaise,
      currency: 'INR',
      receipt: booking.booking_ref
    });

    db.prepare('UPDATE bookings SET razorpay_order_id = ? WHERE id = ?').run(order.id, booking.id);

    res.json({ demo_mode: false, key_id: process.env.RAZORPAY_KEY_ID, order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not start payment. Please try again.' });
  }
});

// POST /api/payment/verify
router.post('/verify', requireAuth, (req, res) => {
  const { booking_id, demo_mode, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

  try {
    const booking = db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?').get(booking_id, req.user.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found.' });

    if (demo_mode) {
      db.prepare(`
        UPDATE bookings SET status = 'confirmed', payment_status = 'paid' WHERE id = ?
      `).run(booking.id);
      return res.json({ message: 'Payment successful (demo mode).' });
    }

    if (!hasRazorpayKeys) {
      return res.status(400).json({ error: 'Payment gateway is not configured.' });
    }

    const crypto = require('crypto');
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({ error: 'Payment verification failed.' });
    }

    db.prepare(`
      UPDATE bookings
      SET status = 'confirmed', payment_status = 'paid', razorpay_payment_id = ?
      WHERE id = ?
    `).run(razorpay_payment_id, booking.id);

    res.json({ message: 'Payment successful.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not verify payment.' });
  }
});

module.exports = router;