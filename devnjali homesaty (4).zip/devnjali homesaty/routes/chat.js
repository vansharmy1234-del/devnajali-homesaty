const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { optionalAuth } = require('../middleware/auth');

const HOMESTAY_PHONE = process.env.HOMESTAY_PHONE || '+91 95688 31926';

// Simple FAQ fallback bot — used whenever no Anthropic API key is configured
function faqReply(message) {
  const m = message.toLowerCase();

  if (m.includes('price') || m.includes('rate') || m.includes('cost') || m.includes('₹')) {
    return 'Our AC rooms are ₹1,800/night and Non-AC rooms are ₹1,100/night. You can see live availability on the Rooms page.';
  }
  if (m.includes('room') && (m.includes('available') || m.includes('book'))) {
    return 'You can check live availability and book directly from our Rooms & Rates page — just pick your dates there.';
  }
  if (m.includes('check') && (m.includes('in') || m.includes('out'))) {
    return 'Check-in is from 12:00 PM and check-out is by 11:00 AM. Early check-in/late check-out can be arranged on request.';
  }
  if (m.includes('cancel')) {
    return 'You can cancel any booking from "My Bookings" in your account dashboard.';
  }
  if (m.includes('contact') || m.includes('phone') || m.includes('call')) {
    return `You can reach us directly at ${HOMESTAY_PHONE}.`;
  }
  if (m.includes('wifi') || m.includes('ac') || m.includes('amenit')) {
    return 'All our rooms include free high-speed Wi-Fi, an attached bathroom with hot water, and a work desk. AC rooms also have a split air conditioner.';
  }

  return `Thanks for your message! For anything specific, feel free to call us at ${HOMESTAY_PHONE} and our team will help right away.`;
}

async function getClaudeReply(message) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  const fetch = require('node-fetch');
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 300,
      system: 'You are the friendly guest-support chatbot for Devanjali Homestay (7 AC rooms at ₹1800/night, 2 Non-AC rooms at ₹1100/night, check-in 12 PM, check-out 11 AM). Answer guest questions concisely and warmly.',
      messages: [{ role: 'user', content: message }]
    })
  });

  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === 'text');
  return textBlock ? textBlock.text : null;
}

// POST /api/chat
router.post('/', optionalAuth, async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  let reply;
  try {
    reply = await getClaudeReply(message.trim());
  } catch (err) {
    console.error('Claude chat error, falling back to FAQ bot:', err.message);
  }
  if (!reply) reply = faqReply(message.trim());

  try {
    db.prepare('INSERT INTO chat_logs (user_id, message, reply) VALUES (?, ?, ?)')
      .run(req.user ? req.user.id : null, message.trim(), reply);
  } catch (err) {
    console.error('Could not save chat log:', err.message);
  }

  res.json({ reply });
});

module.exports = router;