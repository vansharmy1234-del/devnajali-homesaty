require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

// Ensure DB schema exists, then seed rooms if empty
require('./db/database');
require('./db/seed');

const authRoutes = require('./routes/auth');
const roomRoutes = require('./routes/rooms');
const bookingRoutes = require('./routes/bookings');
const paymentRoutes = require('./routes/payment');
const chatRoutes = require('./routes/chat');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the frontend
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/chat', chatRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', homestay: 'Devanjali Homestay' });
});

// Fallback to index.html for any non-API route (simple SPA-friendly routing)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, 'public', req.path.endsWith('.html') ? req.path : '/index.html'), (err) => {
    if (err) res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });
});

app.listen(PORT, () => {
  console.log(`\n🏡 Devanjali Homestay server running at http://localhost:${PORT}\n`);
});