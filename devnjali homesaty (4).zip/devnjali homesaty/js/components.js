// Loads shared header/footer partials into any page, and reflects login state in the nav.
(function () {
  async function loadPartial(selector, url) {
    const el = document.querySelector(selector);
    if (!el) return;
    try {
      const res = await fetch(url);
      el.innerHTML = await res.text();
    } catch (e) {
      console.error('Failed to load partial:', url, e);
    }
  }

  function setActiveNav() {
    const path = window.location.pathname === '/' ? '/index.html' : window.location.pathname;
    document.querySelectorAll('#main-nav a').forEach(a => {
      if (a.getAttribute('data-path') === path) a.classList.add('active');
    });
  }

  function reflectAuthState() {
    const token = localStorage.getItem('dj_token');
    const userRaw = localStorage.getItem('dj_user');
    const guestActions = document.getElementById('guestActions');
    const userActions = document.getElementById('userActions');
    const authOnlyEls = document.querySelectorAll('.auth-only');
    const guestOnlyEls = document.querySelectorAll('.guest-only');

    if (token && userRaw) {
      const user = JSON.parse(userRaw);
      authOnlyEls.forEach(el => (el.hidden = false));
      guestOnlyEls.forEach(el => (el.hidden = true));
      const nameEl = document.getElementById('headerUserName');
      if (nameEl) nameEl.textContent = '👋 ' + user.name.split(' ')[0];
    } else {
      authOnlyEls.forEach(el => (el.hidden = true));
      guestOnlyEls.forEach(el => (el.hidden = false));
    }

    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('dj_token');
        localStorage.removeItem('dj_user');
        window.location.href = '/index.html';
      });
    }
  }

  function wireMobileNav() {
    const toggle = document.getElementById('navToggle');
    const nav = document.getElementById('main-nav');
    if (toggle && nav) {
      toggle.addEventListener('click', () => nav.classList.toggle('open'));
    }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    await loadPartial('#header-placeholder', '/partials/header.html');
    await loadPartial('#footer-placeholder', '/partials/footer.html');
    setActiveNav();
    reflectAuthState();
    wireMobileNav();
    const yearEl = document.getElementById('year');
    if (yearEl) yearEl.textContent = new Date().getFullYear();
    document.dispatchEvent(new Event('partialsLoaded'));
  });
})();