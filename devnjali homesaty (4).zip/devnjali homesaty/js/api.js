// Small fetch wrapper for talking to the Devanjali Homestay backend API.
const API = {
  base: '/api',

  headers() {
    const token = localStorage.getItem('dj_token');
    const h = { 'Content-Type': 'application/json' };
    if (token) h['Authorization'] = 'Bearer ' + token;
    return h;
  },

  async request(method, path, body) {
    const res = await fetch(this.base + path, {
      method,
      headers: this.headers(),
      body: body ? JSON.stringify(body) : undefined
    });
    let data;
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) {
      throw new Error(data.error || 'Something went wrong. Please try again.');
    }
    return data;
  },

  get(path) { return this.request('GET', path); },
  post(path, body) { return this.request('POST', path, body); },

  isLoggedIn() {
    return !!localStorage.getItem('dj_token');
  },

  currentUser() {
    const raw = localStorage.getItem('dj_user');
    return raw ? JSON.parse(raw) : null;
  },

  requireLogin(redirectTo) {
    if (!this.isLoggedIn()) {
      const target = redirectTo || window.location.pathname + window.location.search;
      window.location.href = '/login.html?redirect=' + encodeURIComponent(target);
      return false;
    }
    return true;
  }
};