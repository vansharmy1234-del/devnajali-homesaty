// Floating AI concierge chat widget — appears on every page.
(function () {
  const SUGGESTIONS = ['Room prices?', 'Where are you located?', 'Do rooms have AC?', 'How do I book?'];

  function widgetHTML() {
    return `
      <div id="chat-panel">
        <div class="chat-header">
          <strong>Devanjali Concierge</strong>
          <span>Usually replies in a few seconds</span>
        </div>
        <div class="chat-body" id="chatBody"></div>
        <div class="chat-suggestions" id="chatSuggestions"></div>
        <div class="chat-input-row">
          <input type="text" id="chatInput" placeholder="Ask about rooms, prices, location…" autocomplete="off">
          <button id="chatSend" aria-label="Send">➤</button>
        </div>
      </div>
      <button id="chat-toggle" aria-label="Open chat">💬</button>
    `;
  }

  function addMessage(body, text, sender) {
    const msg = document.createElement('div');
    msg.className = 'chat-msg ' + sender;
    msg.textContent = text;
    body.appendChild(msg);
    body.scrollTop = body.scrollHeight;
    return msg;
  }

  async function sendMessage(text) {
    const body = document.getElementById('chatBody');
    addMessage(body, text, 'user');

    const thinking = addMessage(body, 'Typing…', 'bot');
    thinking.classList.add('loading-dots');
    thinking.textContent = '';

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: API.headers(),
        body: JSON.stringify({ message: text })
      });
      const data = await res.json();
      thinking.classList.remove('loading-dots');
      thinking.textContent = data.reply || "Sorry, I couldn't process that. Please call +91 95688 31926.";
    } catch (e) {
      thinking.classList.remove('loading-dots');
      thinking.textContent = "I'm having trouble connecting right now. Please call us at +91 95688 31926.";
    }
  }

  function init() {
    const container = document.createElement('div');
    container.id = 'chat-widget';
    container.innerHTML = widgetHTML();
    document.body.appendChild(container);

    const panel = document.getElementById('chat-panel');
    const toggle = document.getElementById('chat-toggle');
    const body = document.getElementById('chatBody');
    const input = document.getElementById('chatInput');
    const sendBtn = document.getElementById('chatSend');
    const suggestionsWrap = document.getElementById('chatSuggestions');

    SUGGESTIONS.forEach(s => {
      const b = document.createElement('button');
      b.textContent = s;
      b.addEventListener('click', () => sendMessage(s));
      suggestionsWrap.appendChild(b);
    });

    toggle.addEventListener('click', () => {
      panel.classList.toggle('open');
      if (panel.classList.contains('open') && !body.dataset.greeted) {
        addMessage(body, 'Namaste! 🙏 I\'m the Devanjali Homestay concierge. Ask me about rooms, prices, amenities, or how to reach us.', 'bot');
        body.dataset.greeted = 'true';
      }
    });

    function handleSend() {
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      sendMessage(text);
    }

    sendBtn.addEventListener('click', handleSend);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') handleSend(); });
  }

  document.addEventListener('DOMContentLoaded', init);
})();